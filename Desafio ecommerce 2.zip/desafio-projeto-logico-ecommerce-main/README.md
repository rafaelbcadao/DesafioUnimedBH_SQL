# Bootcamp Database Experience da Dio.me
# Desafio - Construindo seu Primeiro Projeto Lógico de Banco de Dados - E-Commerce 

## Solução
Foi utilizado o modelador de BD MySQL Workbench especificando as entidades, seus relacionamentos (PKs, FKs) e   
atributos configurando num esquema conceitual para um cenário de e-commerce.
Foi utilizado scripts SQL para a criação do esquema do banco de dados.



