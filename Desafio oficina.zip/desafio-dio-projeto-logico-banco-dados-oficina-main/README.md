# Bootcamp Database Experience da Dio.me
# Desafio - Construa um Projeto Lógico de Banco de Dados do Zero - Oficina

## Solução
Foi utilizado o modelador de BD MySQL Workbench especificando as entidades, seus relacionamentos (PKs, FKs) e   
atributos configurando num esquema conceitual para um cenário de e-commerce.
Foi utilizado scripts SQL para a criação do esquema do banco de dados.



